
def predict_vm(ecs_lines, input_lines):
    # Do your work from here#
    result = []
    if ecs_lines is None:
        print 'ecs information is none'
        return result
    if input_lines is None:
        print 'input file information is none'
        return result
    
    cnt = 0
    flag = 0
    mode = 0 # mode 1 = optimize CPU, mode 2 = optimize MEM
    typeList = []
    trainData = []
    dayList = []
    data = []
    
    RUNYEAR = 0 # wheather a year is é—°å¹´
    CPUTYPE = [0,1,1,1,2,2,2,4,4,4,8,8,8,16,16,16]
    MEMTYPE = [0,1,2,4,2,4,8,4,8,16,8,16,32,16,32,64]
    DAYNUM1 = [0,31,27,31,30,31,30,31,31,30,31,30,31]
    DAYNUM2 = [0,31,28,31,30,31,30,31,31,30,31,30,31]
    YEARS = [0,365,365,365,365,366,365,365,365,366,365,365,365,366,365,365,365,366,365,365,365,366]
    
    # In order to process data across years, I let (2000,1,1) to be the 1st day, then calculate the date of 
    # 1st day of train data(let it be x), and then every date of train data = b - x + 1(b is the date transformed 
    # according to (2000,1,1)

    def cal(year, month, day):
        year = str(year)
        if ((int)(year[0])+(int)(year[1])+(int)(year[2])+(int)(year[3]))%4 == 0:
            RUNYEAR = 1;
        if RUNYEAR == 0:
            datetmp = 0
            for i in range(1,(int)(month)):
                datetmp += DAYNUM1[i]
            datetmp += (int)(day)
        if RUNYEAR == 1:
            datetmp = 0
            for i in range(1,(int)(month)):
                datetmp += DAYNUM2[i]
            datetmp += (int)(day)
        for i in range (1,(int)(year)-2000+1):
            datetmp += (int)(YEARS[i])
        return datetmp
    
    return result
