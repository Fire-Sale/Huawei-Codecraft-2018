#include "predict.h"
//#include <ctime>
#include <time.h>
#include <math.h>
#include <iostream>
#include <string.h>
#include <string>
#include <cstring>
#include <stdio.h>

//added by wenying 
int CPUTYPE[] = {0 , 1, 1, 1, 2, 2, 2, 4, 4, 4, 8, 8, 8, 16, 16, 16};
int MEMTYPE[] = {0, 1, 2, 4, 2, 4, 8, 4, 8, 16, 8, 16, 32, 16, 32, 64};
int DAYNUM2[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
int DAYNUM1[] = {0, 31, 27, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
int YEARS[] = {0, 365, 365, 365, 365, 366, 365, 365, 365, 366, 365, 365, 365, 366, 365, 365, 365, 366, 365, 365, 365, 366};


int cal(int year, int month, int day)
{	
	int RUNYEAR = 0;
	int datetmp = 0;
	if (((year % 4 == 0) && (year % 100) != 0) || (year % 400 == 0))
	{
		RUNYEAR = 1;
	}
	if (RUNYEAR == 0)
	{
		for (int i = 1; i < month; i++)
		{
			datetmp += DAYNUM1[i];
		}
		datetmp += day;
	}
	if (RUNYEAR == 1)
	{
		for (int i = 1; i < month; i++)
		{
			datetmp += DAYNUM2[i];
		}
		datetmp += day;
	}
	for (int i = 1; i < (year - 2000 + 1);i++)
	{
		datetmp+=YEARS[i];
	}
	return datetmp;	
}



//��Ҫ���ɵĹ��������� cputype              traindata            traindata line number  output result 
void predict_server(char * info[MAX_INFO_NUM], char * data[MAX_DATA_NUM], int data_num, char * filename)
{
	
	int cnt=0;
	int flag=0;
	//int mode=0;
	if(data==NULL)
	{
		printf("data information is none\n");
		return ;
	}

	if(info==NULL)
	{
		printf("input file information is none\n");
		return ;
	}	
	int traindata[data_num][3];
	for(int i=0;i<3;i++)
	{
		traindata[0][i]=0;		
	}		
	int startdateorigin=0;	
	for(int index=0;index<data_num;index++)
	{		
		char *item;
		cnt+=1;
		item=data[index];
		char mac[30];		
		char flavortype[30];		
		int flavornum;
		char Date[30];	
		int year,month,day;			
		sscanf(item, "%s %s %s",mac,flavortype,Date);		
		sscanf(flavortype,"%*[^r]r%d",&flavornum);	
		sscanf(Date,"%d-%d-%d",&year,&month,&day);
		int date;
		date=cal(year,month,day);		
		if(cnt==1)
		{			
			startdateorigin=date-1;
		}
		date=date-startdateorigin;
		if(flavornum>=19)
		{
			cnt -= 1;
			continue;
		}
		traindata[cnt][0]=flavornum;
		traindata[cnt][1]=date;
		traindata[cnt][2]=cnt;	
	}	
	int maxDate = traindata[cnt][1];
	float Data[maxDate+60][19];
	for(int i=1;i<maxDate+60;i++)
	{
		Data[i][0]=i;
		for(int j=1;j<19;j++)
		{
			Data[i][j]=0;
		}
	}
	
	
	for(int i=1;i<cnt+1;i++)
	{
		int date ,flavor;		
		date=traindata[i][1];
		flavor=traindata[i][0];				
		Data[date][flavor]+=1;
						
	}	

	//输入文件处理
	int cpuNum,memNum,diskNum;
	int typeNum;
	int typeList[16];                         //初赛默认最大16种类型
	
	int startYear,startMonth,startDay;
	int endYear,endMonth,endDay;	
	for(int index =0;;index++)
	{
		char *item;	
					
		item=info[index];
		
		if(item==NULL)
		{
			break;
		}
		if(index==1)
		{
			sscanf(item,"%*[^ ] %d %d %d",&cpuNum,&memNum,&diskNum);
		}		
		if(index==5)
		{
			sscanf(item,"%d",&typeNum);						
		}
		if(strstr(item,"flavor")!=NULL)
		{
			int flavornum;
			static int index=0;
			sscanf(item,"%*[^r]r%d",&flavornum);	
			typeList[index]=flavornum;
			index++;
						
		}			
		if((strstr(item,"201")!=NULL)&&(flag==0))
		{
			flag=1;
			sscanf(item,"%d-%d-%d",&startYear,&startMonth,&startDay);
		}
		if((strstr(item,"201")!=NULL)&&(flag==1))
		{			
			sscanf(item,"%d-%d-%d",&endYear,&endMonth,&endDay);	
		}

	} 
	
	int startDate,endDate;
	int predictTime;
	int breakTime;
	startDate=cal(startYear,startMonth,startDay);
	endDate=cal(endYear,endMonth,endDay);
	startDate -= startdateorigin;
	endDate -= startdateorigin;
	predictTime =endDate-startDate;
	breakTime = startDate - maxDate;
	predictTime += breakTime;

	float avg[19];
	//float var[16];

	for(int i=0;i<19;i++)
	{
		avg[i]=0;
	//	var[i]=0;
	}
	
	for(int i=1;i<19;i++)
	{
		int tmp=0;
		for(int j=1;j<maxDate+1;j++)
		{
			tmp +=Data[j][i];
		}
		avg[i]=(float)tmp/maxDate;		
	}	

	for(int i=1;i<19;i++)
	{
		for(int j=1;j<maxDate+1;j++)
		{
			if(Data[j][i]>avg[i]*6)
			{
				Data[j][i]=avg[i]*3.8;                
			}
		}
	}
	

	//float DataTmp[60][19];
	float total = 0;
	for(int i=1;i<predictTime+1;i++)
	{
		for(int j=0;j<typeNum;j++)
		{
			float tot=0;
			for(int k=maxDate+i-30;k<maxDate+i+1;k++)
			{
				tot+=Data[k][typeList[j]];				
			}			
			tot = (int)(tot/30);
			total +=tot;		
			Data[maxDate+i][typeList[j]] = tot;			
			Data[maxDate+i][typeList[j]] +=5.3;	
		}				
	}	
	
	
	int predictList[19][2];
	for(int i=0;i<19;i++)
	{
		predictList[i][0] = 0;
		predictList[i][1] = 0;
	}

	int totaltmp=0;
	for(int i=0;i<typeNum;i++)
	{
		float tmp=0;
		for(int j=1;j<predictTime+1-breakTime;j++)
		{			
			tmp+=Data[maxDate+j+breakTime][typeList[i]];
		}		
		
	
		totaltmp +=(int)tmp;
		predictList[typeList[i]][0]=typeList[i];
		predictList[typeList[i]][1]=(int)tmp;
	}	

	int TEST[]={0,8,0,0,0,-2,0,0,0,2,0,0,0,0,0,0,0,0,0};
	for(int i=0;i<16;i++)
	{
		if(predictList[i][1]!=0)
		{
			predictList[i][1]+=TEST[i];
			totaltmp +=TEST[i];                                  
		}
	}	
	
	char  result_file[10000] ="\0";
	char  flavortotal[200];
	sprintf(flavortotal,"%d",totaltmp);
	strcat(flavortotal,"\n");
	strcat(result_file,flavortotal); 	

	for(int i=0;i<typeNum;i++)                                   //依次将结果写入文件
	{
		char tmp2[5],tmp3[10];
		char tmp1[20] = "flavor";
		sprintf(tmp2,"%d",typeList[i]);
		strcat(tmp1,tmp2); 
        strcat(tmp1," ");
		sprintf(tmp3,"%d",predictList[typeList[i]][1]);
		strcat(tmp1,tmp3);
		strcat(tmp1,"\n");
		strcat(result_file,tmp1);			
	}
	strcat(result_file,"\n");	
    
    
	int Q[20000];
	int Qindex=0;
	for(int i=typeNum-1;i>=0;i--)
	{		
		int cnt =1;
		while(cnt<=predictList[typeList[i]][1])
		{						
			Q[Qindex] = predictList[typeList[i]][0];
			Qindex +=1;
			cnt +=1;
		}
	}	
	int minServer = Qindex;
	int dice[minServer];
	int newQ[minServer];
	for(int i=0;i<minServer;i++)
	{
		dice[i] = i;
		newQ[i] = Q[i];
	}
	int curBag = 1;	
	float curT = 100.0;
	float endT = 1;
	float decRate = 0.96;
	int bag[20000][3];
	int usedBag[20000][19];
	int bestServer[20000][19];
	srand((unsigned)time(0));	
    while(curT > endT)
	{			
		// int randIndexarray[Qindex];
		// for(int i=0;i<Qindex;i++)
		// {
		// 	int tmprand;
		// 	tmprand = rand() % Qindex;
		// 	for(int j=0;j<=i;j++)
		// 	{
		// 		if(tmprand != randIndexarray[j]);				
		// 		else
		// 		{
		// 			i -=1;
		// 			break;
		// 		}
		// 		if(j == i)
		// 		{
		// 			randIndexarray[i] = tmprand;
		// 		}
		// 	}
		// }	
		
		// int tmp;	
		// tmp = newQ[dice[randIndexarray[0]]];
		// for(int i=0;i<minServer-1;i++)
		// {			
		// 	newQ[dice[randIndexarray[i]]] = newQ[dice[randIndexarray[i+1]]];
		// }
		// newQ[dice[minServer-1]] = tmp;	

		int randIndex0,randIndex1;
		randIndex0 = rand() % Qindex;
		randIndex1 = rand() % Qindex;	
		int tmpswap;	
		tmpswap = newQ[dice[randIndex0]];
		newQ[dice[randIndex0]] = newQ[dice[randIndex1]];
		newQ[dice[randIndex1]] = tmpswap;

		
		for(int i=0;i<20000;i++)
		{
			bag[i][0]=cpuNum;
			bag[i][1]=memNum;
			bag[i][2]=diskNum;
		}
		for(int i=0;i<20000;i++)
		{
			usedBag[i][0]=i;
			for(int j=1;j<19;j++)
			{
				usedBag[i][j]=0;
			}
		}
		
		int tmpj=0;
		for(int i=0;i<Qindex;i++)
		{
			for(int j=1;j<curBag+1;j++)
			{
				tmpj = j;
				if(((bag[j][0]-CPUTYPE[newQ[i]])>=0)&&((bag[j][1]-MEMTYPE[newQ[i]])>=0))
				{
					bag[j][0] -= CPUTYPE[newQ[i]];
					bag[j][1] -= MEMTYPE[newQ[i]];
					usedBag[j][newQ[i]] +=1;
					break;
				}
			}
			if(tmpj == curBag)
			{				
				curBag +=1;
			}
		}
		int serverNum =0;
		int totCPU = 0;
		int totMEM = 0;
		for(int i=1;i<curBag+1;i++)
		{
			totCPU += bag[i][0];
            totMEM += bag[i][1];
		}
		float usageCPU, usageMEM;
		usageCPU = 1 - (float)totCPU / (cpuNum*curBag);
        usageMEM = 1 - (float)totMEM / (memNum*curBag);
			
		serverNum = curBag - 1 + (usageCPU + usageMEM)/2;
		
		if (serverNum < minServer)
		{
			minServer = serverNum;
			for(int i=0;i<20000;i++)
			{
				bestServer[i][0]=i;
				for(int j=1;j<19;j++)
				{
					bestServer[i][j] = usedBag[i][j];
				}
			}
		}
        else
		{
			if(exp(((float)minServer-(float)serverNum)/curT) > (rand()%100/(double)101))
			{
				minServer = serverNum;
				for(int i=0;i<20000;i++)
				{
					bestServer[i][0]=i;
					for(int j=1;j<19;j++)
					{
						bestServer[i][j] = usedBag[i][j];
					}
				}
			}			
		} 	
		curT = decRate * curT;
	}

	for(int i=0;i<20000;i++)
	{
		usedBag[i][0]=i;
		for(int j=1;j<16;j++)
		{
			usedBag[i][j] = bestServer[i][j];
		}
	}	

	while(1)
	{
		int totTest = 0;
		for(int i = 1;i<19;i++)
		{
			totTest +=usedBag[curBag][i];
		}
		if (totTest != 0)
		{
			break;
		}
		else
		{
			curBag -= 1;
		}		
	}	
	char tmpcurBagtype[20] = "General";	
	char tmpcurBagnum[10];
	strcat(tmpcurBagtype," ");
	sprintf(tmpcurBagnum,"%d",curBag);
	strcat(tmpcurBagtype,tmpcurBagnum);
	strcat(result_file,tmpcurBagtype);
	strcat(result_file,"\n");
	

	char result_file1[10000]="\0";
	 for(int i=1;i<curBag+1;i++)
	 {
		char labeltype[200]="General-";
		char labelnum[10];
		sprintf(labelnum,"%d",i);
		strcat(labeltype,labelnum);
		strcat(labeltype," ");
		strcat(result_file1,labeltype);
	 	for(int j=0;j<typeNum;j++) 
	 	{
			if(usedBag[i][typeList[j]] != 0)
			{
				char tmp2[5],tmp3[10];
				char tmp1[20] = "flavor";
				 sprintf(tmp2,"%d",typeList[j]);
				 strcat(tmp1,tmp2);
				 strcat(tmp1," ");				
				 sprintf(tmp3,"%d",usedBag[i][typeList[j]]);
				 strcat(tmp1,tmp3);
				 strcat(result_file1,tmp1);
				 strcat(result_file1," ");
			}
	 	}
		strcat(result_file1,"\n");
	 }	
	strcat(result_file,result_file1);
	printf("%s\n",result_file);	
	write_result(result_file, filename);
}
